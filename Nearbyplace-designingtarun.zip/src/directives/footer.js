import React from 'react'

function Footer() {
  return (
    <>
        <div className="footer-content">
            <div><strong>Copyright © 2023 <a href="">NEARBY STORES</a>.</strong> All rights reserved.</div>
        </div>
    </>
  )
}

export default Footer